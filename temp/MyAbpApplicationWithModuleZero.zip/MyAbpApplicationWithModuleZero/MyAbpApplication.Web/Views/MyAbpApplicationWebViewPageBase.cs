﻿using Abp.Web.Mvc.Views;

namespace MyAbpApplication.Web.Views
{
    public abstract class MyAbpApplicationWebViewPageBase : MyAbpApplicationWebViewPageBase<dynamic>
    {

    }

    public abstract class MyAbpApplicationWebViewPageBase<TModel> : AbpWebViewPage<TModel>
    {
        protected MyAbpApplicationWebViewPageBase()
        {
            LocalizationSourceName = "MyAbpApplication";
        }
    }
}