﻿using System.Web;
using System.Web.Mvc;
using Abp.Authorization.Users;
using Abp.Runtime.Session;
using Abp.UI;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;

namespace MyAbpApplication.Web.Controllers
{
    public class HomeController : MyAbpApplicationControllerBase
    {
        public IAbpSession AbpSession { get; set; }

        private IAuthenticationManager AuthenticationManager { get { return HttpContext.GetOwinContext().Authentication; } }
        private readonly AbpUserManager _userManager;

        public HomeController(AbpUserManager userManager)
        {
            _userManager = userManager;
            AbpSession = NullAbpSession.Instance;
        }

        public ActionResult Index()
        {
            if (AbpSession.UserId == null) //If it's null then user did not log in.
            {
                Login();
            }
            else
            {
                //You can get current userId
                var userId = AbpSession.UserId.Value;
                //var userId = System.Threading.Thread.CurrentPrincipal.Identity.GetUserId<long>(); //You can also directly use ASP.NET Identity framework but using AbpSession is suggested way.
            }

            return View();
        }

        private void Login()
        {
            //Surely, this informations should be sent from clients
            const string userName = "admin";
            const string password = "123qwe";
            const bool rememberMe = true;

            //Find the user
            var user = _userManager.FindByName(userName);

            //Check password
            if (!_userManager.CheckPassword(user, password))
            {
                throw new UserFriendlyException("User name or password is invalid");
            }

            //Create identity
            var identity = _userManager.CreateIdentityAsync(user, DefaultAuthenticationTypes.ApplicationCookie).Result;

            //Sign in
            AuthenticationManager.SignIn(new AuthenticationProperties { IsPersistent = rememberMe }, identity);
        }
    }
}