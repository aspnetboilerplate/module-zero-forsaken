﻿using Abp.Web.Mvc.Controllers;

namespace MyAbpApplication.Web.Controllers
{
    public abstract class MyAbpApplicationControllerBase : AbpController
    {
        protected MyAbpApplicationControllerBase()
        {
            LocalizationSourceName = "MyAbpApplication";
        }
    }
}