﻿(function() {
    var app = angular.module('app');

    var controllerId = 'app.controllers.views.home';
    app.controller(controllerId, [
        '$scope', function($scope) {
            //...
        }
    ]);
})();