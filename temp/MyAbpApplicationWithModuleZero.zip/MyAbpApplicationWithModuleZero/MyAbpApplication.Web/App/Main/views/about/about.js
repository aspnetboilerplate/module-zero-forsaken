﻿(function() {
    var app = angular.module('app');

    var controllerId = 'app.controllers.views.about';
    app.controller(controllerId, [
        '$scope', function($scope) {
            //...
        }
    ]);
})();