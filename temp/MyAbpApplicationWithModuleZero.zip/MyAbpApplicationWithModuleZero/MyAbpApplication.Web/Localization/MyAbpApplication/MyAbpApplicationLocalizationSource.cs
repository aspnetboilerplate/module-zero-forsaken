﻿using System.Web;
using Abp.Localization.Sources.Xml;

namespace MyAbpApplication.Web.Localization.MyAbpApplication
{
    public class MyAbpApplicationLocalizationSource : XmlLocalizationSource
    {
        public MyAbpApplicationLocalizationSource()
            : base("MyAbpApplication", HttpContext.Current.Server.MapPath("/Localization/MyAbpApplication"))
        {
        }
    }
}